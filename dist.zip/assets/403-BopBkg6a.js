import{c as e,o as t}from"./index-BHKuI4KF.js";const c={class:"403"},r={__name:"403",setup(o){return(s,_)=>(t(),e("div",c," 403 "))}};export{r as default};
