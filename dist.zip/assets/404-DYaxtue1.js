import{c as e,o as t}from"./index-BHKuI4KF.js";const c={class:"404"},r={__name:"404",setup(o){return(s,_)=>(t(),e("div",c," 404 "))}};export{r as default};
